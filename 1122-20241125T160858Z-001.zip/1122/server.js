require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const sequelize = require('./database');
const User = require('./models/User');
const bcrypt = require('bcrypt');
const app = express();
app.use(bodyParser.json());

app.use('/api/users', userRoutes);

(async () => {
    try {
        await sequelize.sync({ force: true });
        console.log('Database synchronized.');

        // Tesztfelhasználók létrehozása
        await User.create({ username: 'admin', password: await bcrypt.hash('adminpass', 10), role: 'admin' });
        await User.create({ username: 'user', password: await bcrypt.hash('userpass', 10), role: 'user' });

        app.listen(3000, () => {
            console.log('Server is running on http://localhost:3000');
        });
    } catch (error) {
        console.error('Error initializing database:', error);
    }
})();
